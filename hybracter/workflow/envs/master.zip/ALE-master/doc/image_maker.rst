.. ALE documentation master file, created by
   sphinx-quickstart on Fri Dec 16 21:11:32 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

image_maker.py
====================

Jump to:
   #. `Running image_maker.py`_
   #. `image_maker.py functions and classes`_

Running image_maker.py
----------------------------

Run the following command::

   $ ./image_maker.py

image_maker.py functions and classes
------------------------------------------

.. automodule:: image_maker
   :members:
